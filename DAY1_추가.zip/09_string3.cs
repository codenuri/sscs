using System;
using static System.Console;

string s1 = new string("AAA");
string s2 = new string("AAA");

string s3 = "BBB";
string s4 = "BBB";
