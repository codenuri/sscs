using System;
using static System.Console;

int    n1 = new int();
string s1 = new string("ABCD");


