using System;
using static System.Console;

string s1 = "AB";
s1[0] = "0";

