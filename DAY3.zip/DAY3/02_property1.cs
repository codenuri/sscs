﻿// 82 page

class Person
{
    public int age;
}

class Program
{
    public static void Main()
    {
        Person p1 = new Person();
       

    }
}
