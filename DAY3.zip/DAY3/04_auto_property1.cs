// auto-implemented property
class Example
{
    private int data1 = 0;

}

class Program
{
    public static void Main()
    {

    }
}
