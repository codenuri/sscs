﻿class Student
{
    private string name;
    private int age;
    private int id;
}

class Professor
{
    private string name;
    private int age;
    private int major;
}


