﻿using static System.Console;

class Base
{
    public Base() { WriteLine("Base()"); }
    public Base(int a) { WriteLine("Base(int)"); }
}
class Derived : Base
{
    public Derived()
    {
        WriteLine("Derived()");
    }
    public Derived(int a)
    {
        WriteLine("Derived(int)");
    }
}

class Program
{
    public static void Main()
    {
        Derived d1 = new Derived();
        //      Derived d2 = new Derived(3);
    }
}