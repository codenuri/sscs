﻿class Person
{
    private string name;
    private int age;

    public Person(string n, int a) => (name, age) = (n, a);
}

// Person 으로 부터 상속받는 Student 만들어 보세요 
// 1. int id 추가해 보세요
// 2. Student 생성자 만들어 보세요
// 3. Main 에서 Student 객체 생성해 보세요

class Program
{
    public static void Main()
    {

    }
}