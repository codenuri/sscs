using static System.Console;

class Point3D
{
	private int x, y, z;

	public Point3D(int a, int b, int c)
		=> (x, y, z) = (a, b, c);
}

class Program 
{
	public static void Main()
	{
        Point3D p = new Point3D(1, 2, 3);

        // �Ʒ� ������ ������ ���ô�.

        (int a1, int a2, int a3) = p;

		WriteLine($"{a1}, {a2}, {a3}");
	}
}