
class Program 
{
	public static void M1(){}
	public static void M2(int arg){}
	public static void M3(double arg){}
	public static void M4(int arg1, double arg2){}

	public static void Main()
	{
		? a1 = M1;
		? a2 = M2;
		? a3 = M3;
		? a4 = M4;
    }
}
