using static System.Console;

delegate void MyFunc(int arg);

class Program
{
    public static void SMethod(int arg) => WriteLine("SMethod");
    public        void IMethod(int arg) => WriteLine("IMethod");

    public static void Main()
    {
		MyFunc f1 = Program.SMethod; // ?
		MyFunc f2 = SMethod;		 // ?
		MyFunc f3 = IMethod;		 // ?

		p.InstanceMethod();
	}

	public void InstanceMethod()
	{
	}
}
