using System;
using static System.Console;


class Program
{
	public static void Foo(int arg) { WriteLine($"Foo : {arg}"); }

    public static void Main()
	{
		int    n = 10;
		double d = 3.4;
		string s = "abc";	

		? f = Foo;
	}


}
