class Widow
{
	public void Method1() { }
    public void Method2() { }
}
