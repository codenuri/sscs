﻿using static System.Console;

// #1. 대부분 메소드는 주어진 작업을 수행하다가 실패 할수도 있다

class DB
{
    public void Backup() 
    {
    }

    public void Remove() { WriteLine("Remove DB");  }
}
class Program
{
    public static void Main()
    {
        DB db = new DB();

        db.Backup();
        db.Remove();
    }
}
