class Point
{
	public int X { get; set; } = 0;
    public int Y { get; set; } = 0;
}

class Program
{
    public static void Main()
    {
        Point p = new Point();
        p.X = 1;
        p.X = 2;
    }
}