using static System.Console;

class Digit 
{
    public int Value { get; set; }

    public Digit(int n) => Value = n;

    public int CompareTo(Digit other)
    {
        return Value.CompareTo(other.Value);    
    }
}

class Program
{
    public static void Main()
    {
        Digit d1 = new Digit(3);
        Digit d2 = new Digit(4);

        int ret = d1.CompareTo(d2);

    }
}


