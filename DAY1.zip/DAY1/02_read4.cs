using System;

Console.Write("press any key >> ");

int n = Console.Read();
