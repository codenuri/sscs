int    n = 0;
double d = 0;
string s = "A";

