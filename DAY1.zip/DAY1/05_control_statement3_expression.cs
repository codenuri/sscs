using System;

int n = 1;

int a = 1 + 2 + 3;

int b = (n + 2) * 3;

n = 3;

Console.WriteLine($"{n = 5}");
