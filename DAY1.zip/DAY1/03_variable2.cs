using static System.Console;

// 초기화되지 않은 변수의 특징
int n;
int a = 0;

a = n;			
WriteLine(n);	

