﻿using static System.Console;

int a = 10;
int b = 20;

// 변수의 값을 출력하는 방법.
WriteLine(a);


