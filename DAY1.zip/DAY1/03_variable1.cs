// 19page ~ 
// #1. Data type
int    n = 0;
double d = 3.4;
char   c = 'A';
string s = "hello";


// #2. var
int v1 = 10;		



// #3. literal
int a1 = 10;		// 10진수

int b1 = 1000000;	// 큰 값을 사용하는 경우


