// 23 page ~
using System;

int   n1 = 0;


double d1 = 0;


string s1 = "A";
