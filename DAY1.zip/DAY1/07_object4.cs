using static System.Console;

class Car 
{	
}

class Program
{
	public static void Main()
	{
		Car c = new Car();

	}
}
