using static System.Console;

// #1. casting
double d = 3.4;
int n1 = d;		// ?


// #2. nameof
int color = 100;

WriteLine($"color" : {color}");


string s = "abcd";
