﻿// 36 page ~
string s1 = "hello";
string s2 = null;	// ok	

int n1 = 0;
// int n2 = null;	// error

 
  

