using static System.Console;

class Program
{
	public static void no_modifier_parameter(int x)
	{
		int n = x;
		x = 0;
	}

	public static void out_parameter(out int x)
	{
		int n = x;	
		x = 0;		
	}

	public static void ref_parameter(ref int x)
	{
		int n = x;	
		x = 0;		
	}

	public static void Main()
	{
		int n1;
		int n2 = 0;

		out_parameter(out n1); 
		out_parameter(out n2); 
		ref_parameter(ref n1); 
		ref_parameter(ref n2); 
		out_parameter(out int n3); 

	}
}