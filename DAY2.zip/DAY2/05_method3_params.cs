class Program
{
    public static void M1(int a1) { }
    public static void M2(int a1, int a2) { }
    public static void M3(int[] ar) { }
	public static void M4(int[] ar) { }

    public static void Main()
    {
    }

    // ���� ����
//  public static void M5(int[] ar, int n) { }			
//	public static void M6(params int[] ar, int n) { }	

}
	