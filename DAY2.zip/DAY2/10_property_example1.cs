class Example1
{
    private int data1 = 0;
    private int data2 = 0;
    private int data3 = 0;
    private int data4 = 0;
    private int data5 = 0;

    // property �� ����� ���ô�.
}

class Program
{
    public static void Main()
    {
        Example1 e1 = new Example();

    }
}
