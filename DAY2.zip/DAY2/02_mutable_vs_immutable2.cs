﻿using System;
using static System.Console;

string s1 = "AB";
string s2 = s1;

WriteLine($"{s2[0]}"); // 'A'

s2[0] = 'X'; 

s2 = "XY"; 

