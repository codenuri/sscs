// 54 page ~ 
using static System.Console;

class Program
{
	public static void Inc(int x)
	{
		++x;
	}

	public static void Main()
	{
		int n = 0;

		WriteLine(n); // 0 ? 1

	}
}