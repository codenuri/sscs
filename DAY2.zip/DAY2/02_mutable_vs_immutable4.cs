﻿using System;
using System.Text;
using static System.Console;

string s = "AB";
s[0] = 'X';