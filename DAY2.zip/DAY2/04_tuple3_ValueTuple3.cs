using static System.Console;

class Point
{
	public int x = 0;
	public int y = 0;

	public Point(int a, int b)
	{
		x = a;
		y = b;

	}

	public (int x, int y) Get()
	{
		return (x, y);
	}
}

class Program 
{
	public static void Main()
	{
		Point p = new Point(1,2);
	}
}
