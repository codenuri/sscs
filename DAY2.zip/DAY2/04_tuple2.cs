using static System.Console;

// Tuple 을 생성하는 다양한 방법
Tuple<int, int, int> t1 = new Tuple<int, int, int>(1,2,3);
Tuple<int, int, int> t2 = Tuple.Create(1, 2, 3);
var t3 = new Tuple<int, int, int>(1,2,3);
var t4 = Tuple.Create(1, 2, 3);

