string s1 = "hello";

object o1 = s1;

int n1 = o1;
int n1 = (int)o1; 	

