﻿// 30 page ~
// mutable   : 객체의 속성을 변경할 수 있는 것 
// immutable : 객체의 속성을 변경할 수 없는 것 

int[] x = { 1, 2, 3 };
x[0] = 10;

string s = "ABC";
s[0] = 'X';

