using static System.Console;

class Program
{
	public static void Main()
	{
		string s = "10";

		int n = int.Parse(s);
	}
}