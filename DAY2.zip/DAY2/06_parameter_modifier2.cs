using static System.Console;

class Program
{
	public static int AddSub(int a, int b)
	{		
		return a + b;
	}

	public static void Main()
	{
		int ret2 = AddSub(5, 3);
	}
}